export default class NotFoundModel {
  getMessage() {
    return "Pages your are looking for does not exist.";
  }
}
