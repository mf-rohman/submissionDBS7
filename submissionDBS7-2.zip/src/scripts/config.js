const CONFIG = {
  API_BASE_URL: import.meta.env.VITE_API_BASE_URL,
  PUBLIC_VAPID_KEY: import.meta.env.VITE_PUBLIC_VAPID_KEY,
};

export { CONFIG };
