const CONFIG = {
  API_BASE_URL:
    import.meta.env.API_BASE_URL ?? "https://story-api.dicoding.dev/v1/",
};

export default CONFIG;
